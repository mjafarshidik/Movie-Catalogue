package com.mjafarshidik.moviecatalogue.ui.home

import androidx.recyclerview.widget.RecyclerView
import androidx.test.core.app.ActivityScenario
import androidx.test.espresso.Espresso
import androidx.test.espresso.IdlingRegistry
import androidx.test.espresso.action.ViewActions
import androidx.test.espresso.assertion.ViewAssertions
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import com.mjafarshidik.moviecatalogue.R
import com.mjafarshidik.moviecatalogue.ui.home.EspressoTestsMatchers.hasDrawable
import com.mjafarshidik.moviecatalogue.utils.DataDummy
import com.mjafarshidik.moviecatalogue.utils.EspressoIdlingResource
import org.junit.After
import org.junit.Before
import org.junit.Test

class HomeActivityTest {

    private val dummyMovie = DataDummy.getAllMovies()
    private val dummyTVShow = DataDummy.getAllTvShows()

    @Before
    fun setUp() {
        ActivityScenario.launch(HomeActivity::class.java)
        IdlingRegistry.getInstance().register(EspressoIdlingResource.espressoTestIdlingResource)
    }

    @After
    fun tearDown() {
        IdlingRegistry.getInstance().unregister(EspressoIdlingResource.espressoTestIdlingResource)
    }

    @Test
    fun loadMovies() {
        delayTwoSecond()
        Espresso.onView(withId(R.id.rvMovies)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.rvMovies))
            .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyMovie.size))
    }

    @Test
    fun loadDetailMovies() {
        delayTwoSecond()
        Espresso.onView(withId(R.id.rvMovies)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                ViewActions.click()
            )
        )
        delayTwoSecond()
        Espresso.onView(withId(R.id.imgDetail)).check(ViewAssertions.matches(hasDrawable()))
        Espresso.onView(withId(R.id.cToolBar)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.cToolBar))
            .check(ViewAssertions.matches(withContentDescription(dummyMovie[0].title)))
        Espresso.onView(withId(R.id.tvScore)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvScore))
            .check(ViewAssertions.matches(withText("Score : ${dummyMovie[0].score}")))
        Espresso.onView(withId(R.id.tvDateRelease)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvDateRelease))
            .check(ViewAssertions.matches(withText("Date Release: ${dummyMovie[0].date}")))
        Espresso.onView(withId(R.id.tvGenre)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.lvGenre)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvOverview)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvOverview))
            .check(ViewAssertions.matches(withText(dummyMovie[0].overview)))
    }

    @Test
    fun loadTVShow() {
        Espresso.onView(withText("TV Show")).perform(ViewActions.click())
        delayTwoSecond()
        Espresso.onView(withId(R.id.rvTVShows)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.rvTVShows))
            .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyTVShow.size))
    }

    @Test
    fun loadDetailTVShows() {
        Espresso.onView(withText("TV Show")).perform(ViewActions.click())
        delayTwoSecond()
        Espresso.onView(withId(R.id.rvTVShows)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                0,
                ViewActions.click()
            )
        )
        delayTwoSecond()
        Espresso.onView(withId(R.id.imgDetail)).check(ViewAssertions.matches(hasDrawable()))
        Espresso.onView(withId(R.id.cToolBar)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.cToolBar))
            .check(ViewAssertions.matches(withContentDescription(dummyTVShow[0].title)))
        Espresso.onView(withId(R.id.tvScore)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvScore))
            .check(ViewAssertions.matches(withText("Score : ${dummyTVShow[0].score}")))
        Espresso.onView(withId(R.id.tvDateRelease)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvDateRelease))
            .check(ViewAssertions.matches(withText("Date Release: ${dummyTVShow[0].date}")))
        Espresso.onView(withId(R.id.tvGenre)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.lvGenre)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvOverview)).check(ViewAssertions.matches(isDisplayed()))
        Espresso.onView(withId(R.id.tvOverview))
            .check(ViewAssertions.matches(withText(dummyTVShow[0].overview)))
    }

    private fun delayTwoSecond() {
        try {
            Thread.sleep(2000)
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }
}