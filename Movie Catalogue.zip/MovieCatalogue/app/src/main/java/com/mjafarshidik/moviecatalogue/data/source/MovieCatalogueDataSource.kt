package com.mjafarshidik.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity
import com.mjafarshidik.moviecatalogue.data.source.local.DataGenre

interface MovieCatalogueDataSource {
    fun getMovies(): LiveData<List<DataEntity>>

    fun getDetailMovies(movieId: Int): LiveData<DataEntity>

    fun getMoviesGenre(id: Int) : LiveData<List<DataGenre>>

    fun getTvShows(): LiveData<List<DataEntity>>

    fun getDetailTvShow(tvShowId: Int): LiveData<DataEntity>

    fun getTVShowsGenre(id: Int) : LiveData<List<DataGenre>>
}