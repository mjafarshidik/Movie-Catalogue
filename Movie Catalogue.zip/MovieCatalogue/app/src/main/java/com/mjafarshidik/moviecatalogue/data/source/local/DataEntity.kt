package com.mjafarshidik.moviecatalogue.data.source.local

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class DataEntity(
    var poster: String?,
    var id: Int,
    var title: String?,
    var date: String?,
    var score: String?,
    var overview: String
): Parcelable

@Parcelize
data class DataGenre(
    var name: String?,
    var id: Int?
): Parcelable