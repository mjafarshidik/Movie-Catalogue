package com.mjafarshidik.moviecatalogue.utils

import androidx.recyclerview.widget.DiffUtil
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity

open class UserDiffCallback(
    private val oldListUser: List<DataEntity>,
    private val newListUser: List<DataEntity>
) : DiffUtil.Callback() {
    override fun getOldListSize(): Int {
        return oldListUser.size
    }

    override fun getNewListSize(): Int {
        return newListUser.size
    }

    override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldListUser[oldItemPosition] == newListUser[newItemPosition]
    }

    override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
        return oldListUser[oldItemPosition] == newListUser[newItemPosition]
    }
}