package com.mjafarshidik.moviecatalogue.network

import com.mjafarshidik.moviecatalogue.data.source.remote.movies.ResponseMovies
import com.mjafarshidik.moviecatalogue.data.source.remote.movies.ResultsItems
import com.mjafarshidik.moviecatalogue.data.source.remote.tvshows.ResponseTVShows
import com.mjafarshidik.moviecatalogue.data.source.remote.tvshows.ResultsItemTVShow
import com.mjafarshidik.moviecatalogue.utils.NetworkInfo.API_KEY
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("movie/upcoming")
    fun getMovies(
        @Query("api_key") apiKey: String = API_KEY
    ): Call<ResponseMovies>

    @GET("movie/{id}")
    fun getDetailMovies(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String = API_KEY
    ): Call<ResultsItems>

    @GET("tv/on_the_air")
    fun getTvShows(
        @Query("api_key") apiKey: String = API_KEY
    ): Call<ResponseTVShows>

    @GET("tv/{id}")
    fun getDetailTvShow(
        @Path("id") id: Int,
        @Query("api_key") apiKey: String = API_KEY
    ): Call<ResultsItemTVShow>
}