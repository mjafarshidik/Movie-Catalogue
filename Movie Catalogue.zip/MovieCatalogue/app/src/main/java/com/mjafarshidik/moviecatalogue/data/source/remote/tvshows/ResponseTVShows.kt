package com.mjafarshidik.moviecatalogue.data.source.remote.tvshows

import com.google.gson.annotations.SerializedName

data class ResponseTVShows(

    @field:SerializedName("page")
    val page: Int,

    @field:SerializedName("total_pages")
    val totalPages: Int,

    @field:SerializedName("results")
    val resultsTVShows: List<ResultsItemTVShow>,

    @field:SerializedName("total_results")
    val totalResults: Int
)

data class ResultsItemTVShow(

    @field:SerializedName("first_air_date")
    val firstAirDate: String,

    @field:SerializedName("overview")
    val overview: String,

    @field:SerializedName("poster_path")
    val posterPath: String,

    @field:SerializedName("original_name")
    val originalName: String,

    @field:SerializedName("vote_average")
    val voteAverage: Double,

    @field:SerializedName("id")
    val id: Int,

    @field:SerializedName("genres")
    val genres: List<GenresItemTVShow>,
)

data class GenresItemTVShow(

    @field:SerializedName("name")
    val name: String,

    @field:SerializedName("id")
    val id: Int
)
