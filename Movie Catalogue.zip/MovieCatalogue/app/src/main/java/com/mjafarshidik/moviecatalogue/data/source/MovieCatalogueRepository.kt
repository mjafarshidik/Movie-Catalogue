package com.mjafarshidik.moviecatalogue.data.source

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity
import com.mjafarshidik.moviecatalogue.data.source.local.DataGenre
import com.mjafarshidik.moviecatalogue.data.source.remote.RemoteDataSource
import com.mjafarshidik.moviecatalogue.data.source.remote.movies.GenresItemMovie
import com.mjafarshidik.moviecatalogue.data.source.remote.movies.ResultsItems
import com.mjafarshidik.moviecatalogue.data.source.remote.tvshows.GenresItemTVShow
import com.mjafarshidik.moviecatalogue.data.source.remote.tvshows.ResultsItemTVShow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch

class MovieCatalogueRepository private constructor(private val remoteDataSource: RemoteDataSource) :
    MovieCatalogueDataSource {

    override fun getMovies(): LiveData<List<DataEntity>> {
        val movieResults = MutableLiveData<List<DataEntity>>()
        CoroutineScope(IO).launch {
            remoteDataSource.getMovies(object : RemoteDataSource.LoadMoviesCallback {
                override fun onAllMovieReceived(resultsItems: List<ResultsItems>) {
                    val movieList = ArrayList<DataEntity>()
                    for (item in resultsItems) {
                        val movies = DataEntity(
                            item.posterPath,
                            item.id,
                            item.title,
                            item.releaseDate,
                            item.voteAverage.toString(),
                            item.overview
                        )
                        movieList.add(movies)
                    }
                    movieResults.postValue(movieList)
                }
            })
        }
        return movieResults
    }


    override fun getDetailMovies(movieId: Int): LiveData<DataEntity> {
        val movieResult = MutableLiveData<DataEntity>()
        CoroutineScope(IO).launch {
            remoteDataSource.getDetailMovies(
                movieId,
                object : RemoteDataSource.LoadDetailMovieCallback {
                    override fun onMovieReceived(resultsItems: ResultsItems) {
                        val movie = DataEntity(
                            resultsItems.posterPath,
                            resultsItems.id,
                            resultsItems.title,
                            resultsItems.releaseDate,
                            resultsItems.voteAverage.toString(),
                            resultsItems.overview
                        )
                        movieResult.postValue(movie)
                    }
                })
        }
        return movieResult
    }

    override fun getMoviesGenre(id: Int): LiveData<List<DataGenre>> {
        val movieGenre = MutableLiveData<List<DataGenre>>()
        CoroutineScope(IO).launch {
            remoteDataSource.getMovieGenre(id, object : RemoteDataSource.LoadMovieGenreCallback {
                override fun onMovieGenreReceived(resultsItem: List<GenresItemMovie>) {
                    val genreList = ArrayList<DataGenre>()
                    for (item in resultsItem) {
                        val genM = DataGenre(
                            item.name,
                            item.id
                        )
                        genreList.add(genM)
                    }
                    movieGenre.postValue(genreList)
                }
            })
        }
        return movieGenre
    }

    override fun getTvShows(): LiveData<List<DataEntity>> {
        val tvResults = MutableLiveData<List<DataEntity>>()
        CoroutineScope(IO).launch {
            remoteDataSource.getTvShows(object : RemoteDataSource.LoadTvShowsCallback {
                override fun onAllTVReceived(resultItemTVShows: List<ResultsItemTVShow>) {
                    val tvList = ArrayList<DataEntity>()
                    for (item in resultItemTVShows) {
                        val tvs = DataEntity(
                            item.posterPath,
                            item.id,
                            item.originalName,
                            item.firstAirDate,
                            item.voteAverage.toString(),
                            item.overview
                        )
                        tvList.add(tvs)
                    }
                    tvResults.postValue(tvList)
                }
            })
        }
        return tvResults
    }

    override fun getDetailTvShow(tvShowId: Int): LiveData<DataEntity> {
        val tvResult = MutableLiveData<DataEntity>()
        CoroutineScope(IO).launch {
            remoteDataSource.getDetailTvShow(
                tvShowId,
                object : RemoteDataSource.LoadDetailTvShowCallback {
                    override fun onTVReceived(resultsItemShow: ResultsItemTVShow) {
                        val tv = DataEntity(
                            resultsItemShow.posterPath,
                            resultsItemShow.id,
                            resultsItemShow.originalName,
                            resultsItemShow.firstAirDate,
                            resultsItemShow.voteAverage.toString(),
                            resultsItemShow.overview
                        )
                        tvResult.postValue(tv)
                    }
                })
        }
        return tvResult
    }

    override fun getTVShowsGenre(id: Int): LiveData<List<DataGenre>> {
        val tvGenre = MutableLiveData<List<DataGenre>>()
        CoroutineScope(IO).launch {
            remoteDataSource.getTVGenre(id, object : RemoteDataSource.LoadTVGenreCallback {
                override fun onTVGenreReceived(resultsItemShows: List<GenresItemTVShow>) {
                    val genreList = ArrayList<DataGenre>()
                    for (item in resultsItemShows) {
                        val genTV = DataGenre(
                            item.name,
                            item.id
                        )
                        genreList.add(genTV)
                    }
                    tvGenre.postValue(genreList)
                }
            })
        }
        return tvGenre
    }

    companion object {
        @Volatile
        private var instance: MovieCatalogueRepository? = null

        fun getInstance(remoteData: RemoteDataSource): MovieCatalogueRepository =
            instance ?: synchronized(this) {
                instance ?: MovieCatalogueRepository(remoteData).apply { instance = this }
            }
    }
}