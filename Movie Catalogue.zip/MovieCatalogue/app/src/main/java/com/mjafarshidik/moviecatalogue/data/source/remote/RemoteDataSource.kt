package com.mjafarshidik.moviecatalogue.data.source.remote

import com.mjafarshidik.moviecatalogue.data.source.remote.movies.*
import com.mjafarshidik.moviecatalogue.data.source.remote.tvshows.*
import com.mjafarshidik.moviecatalogue.network.ApiConfig
import com.mjafarshidik.moviecatalogue.utils.EspressoIdlingResource
import retrofit2.await

class RemoteDataSource {
    suspend fun getMovies(callback: LoadMoviesCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.getApiService().getMovies().await().results.let {
            callback.onAllMovieReceived(it)
            EspressoIdlingResource.decrement()
        }
    }

    suspend fun getDetailMovies(movieId: Int, callback: LoadDetailMovieCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.getApiService().getDetailMovies(movieId).await().let {
            callback.onMovieReceived(it)
            EspressoIdlingResource.decrement()
        }
    }

    suspend fun getMovieGenre(id: Int, callback: LoadMovieGenreCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.getApiService().getDetailMovies(id).await().genres.let {
            callback.onMovieGenreReceived(it)
            EspressoIdlingResource.decrement()
        }
    }

    suspend fun getTvShows(callback: LoadTvShowsCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.getApiService().getTvShows().await().resultsTVShows.let {
            callback.onAllTVReceived(it)
            EspressoIdlingResource.decrement()
        }
    }

    suspend fun getDetailTvShow(tvShowId: Int, callback: LoadDetailTvShowCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.getApiService().getDetailTvShow(tvShowId).await().let {
            callback.onTVReceived(it)
            EspressoIdlingResource.decrement()
        }
    }

    suspend fun getTVGenre(id: Int, callback: LoadTVGenreCallback) {
        EspressoIdlingResource.increment()
        ApiConfig.getApiService().getDetailTvShow(id).await().genres.let {
            callback.onTVGenreReceived(it)
            EspressoIdlingResource.decrement()
        }
    }

    interface LoadMoviesCallback {
        fun onAllMovieReceived(resultsItems: List<ResultsItems>)
    }

    interface LoadDetailMovieCallback {
        fun onMovieReceived(resultsItems: ResultsItems)
    }

    interface LoadMovieGenreCallback {
        fun onMovieGenreReceived(resultsItem: List<GenresItemMovie>)
    }

    interface LoadTvShowsCallback {
        fun onAllTVReceived(resultItemTVShows: List<ResultsItemTVShow>)
    }

    interface LoadDetailTvShowCallback {
        fun onTVReceived(resultsItemShow: ResultsItemTVShow)
    }

    interface LoadTVGenreCallback {
        fun onTVGenreReceived(resultsItemShows: List<GenresItemTVShow>)
    }

    companion object {
        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance(): RemoteDataSource =
            instance ?: synchronized(this) {
                instance ?: RemoteDataSource().apply { instance = this }
            }
    }
}