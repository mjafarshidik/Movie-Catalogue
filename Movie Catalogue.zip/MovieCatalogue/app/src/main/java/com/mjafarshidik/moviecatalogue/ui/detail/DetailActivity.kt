package com.mjafarshidik.moviecatalogue.ui.detail

import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.palette.graphics.Palette
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.material.appbar.AppBarLayout
import com.mjafarshidik.moviecatalogue.R
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity
import com.mjafarshidik.moviecatalogue.databinding.ActivityDetailBinding
import com.mjafarshidik.moviecatalogue.utils.NetworkInfo.IMAGE_URL
import com.mjafarshidik.moviecatalogue.viewmodel.ViewModelFactory
import kotlin.math.abs

class DetailActivity : AppCompatActivity(), AppBarLayout.OnOffsetChangedListener {
    private lateinit var detailBinding: ActivityDetailBinding
    private val percentageToShowImage = 20
    private var maxScrollSize = 0
    private var isImageHidden = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailBinding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(detailBinding.root)

        supportActionBar?.hide()

        showLoading(true)

        detailBinding.tbDetail.setNavigationOnClickListener { onBackPressed() }
        detailBinding.abDetail.addOnOffsetChangedListener(this)

        val detailFactory = ViewModelFactory.getInstance(this)
        val detailViewModel = ViewModelProvider(
            this,
            detailFactory
        )[DetailViewModel::class.java]

        val idExtra = intent.getIntExtra(EXTRA_ID, 0)
        val typeExtra = intent.getStringExtra(EXTRA_DETAIL)

        if (typeExtra == "MOVIE") {
            detailViewModel.getDetailMovies(idExtra).observe(this, {
                showData(it)
            })
            detailViewModel.getMovieGenre(idExtra).observe(this, { listDataGenre ->
                val listGenre = listDataGenre.map { dataGenre ->
                    "${dataGenre.name} "
                }
                detailBinding.lvGenre.adapter =
                    ArrayAdapter(this, R.layout.items_genre, listGenre)
            })
        } else {
            detailViewModel.getDetailTvShow(idExtra).observe(this, {
                showData(it)
            })
            detailViewModel.getTVShowsGenre(idExtra).observe(this, {
                val listGenre = it.map { dataGenre ->
                    "${dataGenre.name} "
                }
                detailBinding.lvGenre.adapter =
                    ArrayAdapter(this, R.layout.items_genre, listGenre)
            })
        }
    }

    private fun showLoading(state: Boolean) {
        detailBinding.apply {
            pbDetail.isVisible = state
            abDetail.isInvisible = state
            nscDetail.isInvisible = state
        }
    }

    override fun onOffsetChanged(appBarLayout: AppBarLayout?, verticalOffset: Int) {
        if (maxScrollSize == 0) maxScrollSize = appBarLayout!!.totalScrollRange

        val currentScrollPercentage: Int = (abs(verticalOffset) * 100 / maxScrollSize)

        if (currentScrollPercentage >= percentageToShowImage) {
            if (!isImageHidden) {
                isImageHidden = true
            }
        }

        if (currentScrollPercentage < percentageToShowImage) {
            if (isImageHidden) {
                isImageHidden = false
            }
        }
    }

    private fun setColor(poster: Bitmap) {
        Palette.from(poster).generate { palette ->
            val defValue = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                resources.getColor(R.color.blue, theme)
            } else {
                TODO("VERSION.SDK_INT < M")
            }
            detailBinding.apply {
                cvDetail.setCardBackgroundColor(
                    palette?.getDarkMutedColor(defValue) ?: defValue
                )
                cToolBar.setContentScrimColor(
                    palette?.getDarkMutedColor(defValue) ?: defValue
                )
                window.statusBarColor = palette?.getDarkMutedColor(defValue) ?: defValue
            }
        }
    }

    private fun showData(dataEntity: DataEntity) {
        showLoading(false)

        detailBinding.apply {
            cToolBar.title = dataEntity.title
            tvDateRelease.text = resources.getString(R.string.date_release, dataEntity.date)
            tvScore.text = resources.getString(R.string.score, dataEntity.score.toString())
            tvOverview.text = dataEntity.overview
            imgDetail.tag = dataEntity.poster
        }
        Glide.with(this)
            .asBitmap()
            .load(IMAGE_URL + dataEntity.poster)
            .centerCrop()
            .apply(
                RequestOptions.placeholderOf(R.drawable.ic_loading)
                    .error(R.drawable.ic_error)
            )
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                    detailBinding.imgDetail.setImageBitmap(resource)
                    setColor(resource)
                }

                override fun onLoadCleared(placeholder: Drawable?) {

                }
            })
    }

    companion object {
        const val EXTRA_ID = "extra_id"
        const val EXTRA_DETAIL = "extra_detail"
    }
}