package com.mjafarshidik.moviecatalogue.ui.tvshows

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.mjafarshidik.moviecatalogue.data.source.MovieCatalogueRepository
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity

class TVShowsViewModel(private val dataRepository: MovieCatalogueRepository) : ViewModel() {

    fun getTv(): LiveData<List<DataEntity>> = dataRepository.getTvShows()
}