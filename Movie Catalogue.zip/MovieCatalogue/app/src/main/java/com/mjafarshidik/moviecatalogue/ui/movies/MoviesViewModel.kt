package com.mjafarshidik.moviecatalogue.ui.movies

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.mjafarshidik.moviecatalogue.data.source.MovieCatalogueRepository
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity

class MoviesViewModel(private val dataRepository: MovieCatalogueRepository) : ViewModel() {

    fun getMovies(): LiveData<List<DataEntity>> = dataRepository.getMovies()
}