package com.mjafarshidik.moviecatalogue.ui.home

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.tabs.TabLayoutMediator
import com.mjafarshidik.moviecatalogue.R
import com.mjafarshidik.moviecatalogue.databinding.ActivityHomeBinding
import com.mjafarshidik.moviecatalogue.ui.movies.MoviesFragment
import com.mjafarshidik.moviecatalogue.ui.tvshows.TVShowsFragment

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setHomeViewPager()
    }

    private fun setHomeViewPager() {
        val fragmentList = listOf(MoviesFragment(), TVShowsFragment())
        val tabTitle =
            listOf(resources.getString(R.string.movie), resources.getString(R.string.tv_show))

        binding.apply {
            vpHome.adapter = ViewPagerAdapter(fragmentList, supportFragmentManager, lifecycle)
            TabLayoutMediator(tlHome, vpHome) { tab, position ->
                tab.text = tabTitle[position]
            }.attach()
        }
    }
}