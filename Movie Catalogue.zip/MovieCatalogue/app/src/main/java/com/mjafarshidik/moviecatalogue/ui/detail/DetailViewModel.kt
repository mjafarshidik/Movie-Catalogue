package com.mjafarshidik.moviecatalogue.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.mjafarshidik.moviecatalogue.data.source.MovieCatalogueRepository
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity
import com.mjafarshidik.moviecatalogue.data.source.local.DataGenre

class DetailViewModel(private val dataRepository: MovieCatalogueRepository) : ViewModel() {

    fun getDetailMovies(id: Int): LiveData<DataEntity> = dataRepository.getDetailMovies(id)

    fun getDetailTvShow(id: Int): LiveData<DataEntity> = dataRepository.getDetailTvShow(id)

    fun getMovieGenre(id: Int): LiveData<List<DataGenre>> = dataRepository.getMoviesGenre(id)

    fun getTVShowsGenre(id: Int): LiveData<List<DataGenre>> = dataRepository.getTVShowsGenre(id)

}