package com.mjafarshidik.moviecatalogue.utils

import com.mjafarshidik.moviecatalogue.R
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity
import com.mjafarshidik.moviecatalogue.data.source.local.DataGenre
import com.mjafarshidik.moviecatalogue.data.source.remote.movies.GenresItemMovie
import com.mjafarshidik.moviecatalogue.data.source.remote.movies.ResultsItems
import com.mjafarshidik.moviecatalogue.data.source.remote.tvshows.GenresItemTVShow
import com.mjafarshidik.moviecatalogue.data.source.remote.tvshows.ResultsItemTVShow


object DataDummy {
    fun getAllMovies(): List<DataEntity> {
        val movies = ArrayList<DataEntity>()

        movies.add(
            DataEntity(
                poster = "https://image.tmdb.org/t/p/w185/lNyLSOKMMeUPr1RsL4KcRuIXwHt.jpg",
                id = 580489,
                title = "Venom: Let There Be Carnage",
                date = "2021-09-30",
                score = "6.8",
                overview = "After finding a host body in investigative reporter Eddie Brock, the alien symbiote must face a new enemy, Carnage, the alter ego of serial killer Cletus Kasady."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.shang_chi}",
                2,
                "Shang-Chi and the Legend of the Ten Rings",
                "2021",
                "72/100",
                "Shang-Chi, the master of weaponry-based Kung Fu, is forced to confront his past after being drawn into the Ten Rings organization."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.black_widow}",
                3,
                "Black Widow",
                "2021",
                "72/100",
                "Natasha Romanoff confronts the darker parts of her ledger when a dangerous conspiracy with ties to her past arises."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.venom_2}",
                4,
                "Venom: Let There Be Carnage",
                "2021",
                "72/100",
                "Eddie Brock attempts to reignite his career by interviewing serial killer Cletus Kasady, who becomes the host of the symbiote Carnage and escapes prison after a failed execution."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.suicide_squad}",
                5,
                "The Suicide Squad",
                "2021",
                "72/100",
                "Supervillains Harley Quinn, Bloodsport, Peacemaker and a collection of nutty cons at Belle Reve prison join the super-secret, super-shady Task Force X as they are dropped off at the remote, enemy-infused island of Corto Maltese."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.cruella}",
                6,
                "Cruella",
                "2021",
                "72/100",
                "A live-action prequel feature film following a young Cruella de Vil."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.free_guy}",
                7,
                "Free Guy",
                "2021",
                "72/100",
                "A bank teller discovers that he's actually an NPC inside a brutal, open world video game."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.spiderman_2}",
                8,
                "Spider-Man: Far from Home",
                "2019",
                "72/100",
                "Following the events of Avengers: Endgame (2019), Spider-Man must step up to take on new threats in a world that has changed forever."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.the_social_dilemma}",
                9,
                "The Social Dilemma",
                "2020",
                "72/100",
                "Explores the dangerous human impact of social networking, with tech experts sounding the alarm on their own creations."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.parasite}",
                10,
                "Parasite",
                "2019",
                "72/100",
                "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan."
            )
        )

        movies.add(
            DataEntity(
                "${R.drawable.captain_marvel}",
                11,
                "Captain Marvel",
                "2019",
                "72/100",
                "Carol Danvers becomes one of the universe's most powerful heroes when Earth is caught in the middle of a galactic war between two alien races."
            )
        )

        return movies
    }

    fun getAllTvShows(): List<DataEntity> {
        val tvShows = ArrayList<DataEntity>()

        tvShows.add(
            DataEntity(
                poster = "https://image.tmdb.org/t/p/w185/iF8ai2QLNiHV4anwY1TuSGZXqfN.jpg",
                id = 3256397,
                title = "Chucky",
                date = "2021-10-12",
                score = "8.0",
                overview = "After a vintage Chucky doll turns up at a suburban yard sale, an idyllic American town is thrown into chaos as a series of horrifying murders begin to expose the town’s hypocrisies and secrets. Meanwhile, the arrival of enemies — and allies — from Chucky’s past threatens to expose the truth behind the killings, as well as the demon doll’s untold origins."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.squid_game}",
                1,
                "Squid Game",
                "2021",
                "66/100",
                "Hundreds of cash-strapped players accept a strange invitation to compete in children's games. Inside, a tempting prize awaits with deadly high stakes. A survival game that has a whopping 45.6 billion-won prize at stake."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.money_heist}",
                2,
                "Money Heist",
                "2017–2021",
                "66/100",
                "An unusual group of robbers attempt to carry out the most perfect robbery in Spanish history - stealing 2.4 billion euros from the Royal Mint of Spain."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.loki}",
                3,
                "Loki",
                "2021",
                "66/100",
                "The mercurial villain Loki resumes his role as the God of Mischief in a new series that takes place after the events of “Avengers: Endgame.”"
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.falcon}",
                4,
                "The Falcon and the Winter Soldier",
                "2021",
                "66/100",
                "Following the events of 'Avengers: Endgame,' Sam Wilson/Falcon and Bucky Barnes/Winter Soldier team up in a global adventure that tests their abilities -- and their patience."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.start_up}",
                5,
                "Start-up",
                "2020",
                "66/100",
                "Young entrepreneurs aspiring to launch virtual dreams into reality compete for success and love in the cutthroat world of Korea's high-tech industry."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.what_if}",
                6,
                "What If...?",
                "2020",
                "66/100",
                "Exploring pivotal moments from the Marvel Cinematic Universe and turning them on their head, leading the audience into uncharted territory."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.wanda_vision}",
                7,
                "WandaVision",
                "2021",
                "66/100",
                "Blends the style of classic sitcoms with the MCU, in which Wanda Maximoff and Vision - two super-powered beings living their ideal suburban lives - begin to suspect that everything is not as it seems."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.alice_in_borderland}",
                8,
                "Alice in Borderland",
                "2020",
                "66/100",
                "A group of bored delinquents are transported to a parallel wasteland as part of a survival game."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.monster_at_works}",
                9,
                "Monsters at Work",
                "2021",
                "66/100",
                "Tylor Tuskman had just graduated from Monster's University at the top of his scare class and has been recruited at Monsters Inc. as a scarer. However, the day before he started, Waternoose was canned. With Mike and Sully now in charge, the whole corporation is transitioning to a joke company. Tylor now needs to figure out how to become a jokester."
            )
        )

        tvShows.add(
            DataEntity(
                "${R.drawable.family_guys}",
                10,
                "Family Guy",
                "1999",
                "66/100",
                "In a wacky Rhode Island town, a dysfunctional family strive to cope with everyday life as they are thrown from one crazy scenario to another."
            )
        )
        return tvShows
    }

    fun generateDummyMovieGenre(): List<DataGenre> {

        val movieGenre = ArrayList<DataGenre>()

        movieGenre.add(DataGenre("Drama", 18))
        movieGenre.add(DataGenre("Sci-Fi & Fantasy", 10765))

        return movieGenre
    }

    fun generateDummyTVGenre(): List<DataGenre> {

        val tvGenre = ArrayList<DataGenre>()

        tvGenre.add(DataGenre("Fantasy", 14))
        tvGenre.add(DataGenre("Action", 28))
        tvGenre.add(DataGenre("Adventure", 12))
        tvGenre.add(DataGenre("Science Fiction", 878))
        tvGenre.add(DataGenre("Thriller", 53))

        return tvGenre
    }

    fun generateDummyMoviesRemote(): List<ResultsItems> {

        val movies = ArrayList<ResultsItems>()
        val genre = ArrayList<GenresItemMovie>()

        movies.add(
            ResultsItems(
                posterPath = "https://image.tmdb.org/t/p/w185/lNyLSOKMMeUPr1RsL4KcRuIXwHt.jpg",
                id = 580489,
                title = "Venom: Let There Be Carnage",
                releaseDate = "2021-04-07",
                voteAverage = 6.8,
                genres = genre,
                overview = "After finding a host body in investigative reporter Eddie Brock, the alien symbiote must face a new enemy, Carnage, the alter ego of serial killer Cletus Kasady."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.shang_chi}",
                id = 2,
                title = "Shang-Chi and the Legend of the Ten Rings",
                releaseDate = "2021",
                voteAverage = 7.2,
                genres = genre,
                overview = "Shang-Chi, the master of weaponry-based Kung Fu, is forced to confront his past after being drawn into the Ten Rings organization."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.black_widow}",
                id = 3,
                title = "Black Widow",
                releaseDate = "2021",
                genres = genre,
                voteAverage = 6.9,
                overview = "Natasha Romanoff confronts the darker parts of her ledger when a dangerous conspiracy with ties to her past arises."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.venom_2}",
                id = 4,
                title = "Venom: Let There Be Carnage",
                releaseDate = "2021",
                genres = genre,
                voteAverage = 8.0,
                overview = "Eddie Brock attempts to reignite his career by interviewing serial killer Cletus Kasady, who becomes the host of the symbiote Carnage and escapes prison after a failed execution."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.suicide_squad}",
                id = 5,
                title = "The Suicide Squad",
                genres = genre,
                releaseDate = "2021",
                voteAverage = 5.7,
                overview = "Supervillains Harley Quinn, Bloodsport, Peacemaker and a collection of nutty cons at Belle Reve prison join the super-secret, super-shady Task Force X as they are dropped off at the remote, enemy-infused island of Corto Maltese."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.cruella}",
                id = 6,
                title = "Cruella",
                releaseDate = "2021",
                genres = genre,
                voteAverage = 7.8,
                overview = "A live-action prequel feature film following a young Cruella de Vil."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.free_guy}",
                id = 7,
                title = "Free Guy",
                releaseDate = "2021",
                genres = genre,
                voteAverage = 8.3,
                overview = "A bank teller discovers that he's actually an NPC inside a brutal, open world video game."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.spiderman_2}",
                id = 8,
                title = "Spider-Man: Far from Home",
                releaseDate = "2019",
                genres = genre,
                voteAverage = 6.6,
                overview = "Following the events of Avengers: Endgame (2019), Spider-Man must step up to take on new threats in a world that has changed forever."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.the_social_dilemma}",
                id = 9,
                title = "The Social Dilemma",
                releaseDate = "2020",
                genres = genre,
                voteAverage = 5.9,
                overview = "Explores the dangerous human impact of social networking, with tech experts sounding the alarm on their own creations."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.parasite}",
                id = 10,
                title = "Parasite",
                genres = genre,
                releaseDate = "2019",
                voteAverage = 8.4,
                overview = "Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan."
            )
        )

        movies.add(
            ResultsItems(
                posterPath = "${R.drawable.captain_marvel}",
                id = 11,
                title = "Captain Marvel",
                genres = genre,
                releaseDate = "2019",
                voteAverage = 8.4,
                overview = "Carol Danvers becomes one of the universe's most powerful heroes when Earth is caught in the middle of a galactic war between two alien races."
            )
        )

        return movies
    }

    fun generateDummyTVShowsRemote(): List<ResultsItemTVShow> {

        val tvShows = ArrayList<ResultsItemTVShow>()
        val genre = ArrayList<GenresItemTVShow>()

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "https://image.tmdb.org/t/p/w185/iF8ai2QLNiHV4anwY1TuSGZXqfN.jpg",
                id = 3256397,
                originalName = "Chucky",
                genres = genre,
                firstAirDate = "2021-10-12",
                voteAverage = 8.0,
                overview = "After a vintage Chucky doll turns up at a suburban yard sale, an idyllic American town is thrown into chaos as a series of horrifying murders begin to expose the town’s hypocrisies and secrets. Meanwhile, the arrival of enemies — and allies — from Chucky’s past threatens to expose the truth behind the killings, as well as the demon doll’s untold origins."


            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.squid_game}",
                id = 1,
                originalName = "Squid Game",
                genres = genre,
                firstAirDate = "2021",
                voteAverage = 6.6,
                overview = "Hundreds of cash-strapped players accept a strange invitation to compete in children's games. Inside, a tempting prize awaits with deadly high stakes. A survival game that has a whopping 45.6 billion-won prize at stake."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.money_heist}",
                id = 2,
                originalName = "Money Heist",
                firstAirDate = "2017–2021",
                genres = genre,
                voteAverage = 7.6,
                overview = "An unusual group of robbers attempt to carry out the most perfect robbery in Spanish history - stealing 2.4 billion euros from the Royal Mint of Spain."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.loki}",
                id = 3,
                originalName = "Loki",
                genres = genre,
                firstAirDate = "2021",
                voteAverage = 7.6,
                overview = "The mercurial villain Loki resumes his role as the God of Mischief in a new series that takes place after the events of “Avengers: Endgame.”"
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.falcon}",
                id = 4,
                originalName = "The Falcon and the Winter Soldier",
                genres = genre,
                firstAirDate = "2021",
                voteAverage = 7.0,
                overview = "Following the events of 'Avengers: Endgame,' Sam Wilson/Falcon and Bucky Barnes/Winter Soldier team up in a global adventure that tests their abilities -- and their patience."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.start_up}",
                id = 5,
                originalName = "Start-up",
                genres = genre,
                firstAirDate = "2020",
                voteAverage = 7.7,
                overview = "Young entrepreneurs aspiring to launch virtual dreams into reality compete for success and love in the cutthroat world of Korea's high-tech industry."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.what_if}",
                id = 6,
                originalName = "What If...?",
                genres = genre,
                firstAirDate = "2021",
                voteAverage = 7.5,
                overview = "Exploring pivotal moments from the Marvel Cinematic Universe and turning them on their head, leading the audience into uncharted territory."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.wanda_vision}",
                id = 7,
                originalName = "WandaVision",
                genres = genre,
                firstAirDate = "2021",
                voteAverage = 8.6,
                overview = "Blends the style of classic sitcoms with the MCU, in which Wanda Maximoff and Vision - two super-powered beings living their ideal suburban lives - begin to suspect that everything is not as it seems."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.alice_in_borderland}",
                id = 8,
                originalName = "Alice in Borderland",
                genres = genre,
                firstAirDate = "2020",
                voteAverage = 7.2,
                overview = "A group of bored delinquents are transported to a parallel wasteland as part of a survival game."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.monster_at_works}",
                id = 9,
                originalName = "Monsters at Work",
                genres = genre,
                firstAirDate = "2021",
                voteAverage = 7.8,
                overview = "Tylor Tuskman had just graduated from Monster's University at the top of his scare class and has been recruited at Monsters Inc. as a scarer. However, the day before he started, Waternoose was canned. With Mike and Sully now in charge, the whole corporation is transitioning to a joke company. Tylor now needs to figure out how to become a jokester."
            )
        )

        tvShows.add(
            ResultsItemTVShow(
                posterPath = "${R.drawable.family_guys}",
                id = 10,
                originalName = "Family Guy",
                genres = genre,
                firstAirDate = "1999",
                voteAverage = 8.7,
                overview = "In a wacky Rhode Island town, a dysfunctional family strive to cope with everyday life as they are thrown from one crazy scenario to another."
            )
        )

        return tvShows
    }

    fun generateDummyMovieGenreRemote(): List<GenresItemMovie> {

        val movieGenre = ArrayList<GenresItemMovie>()

        movieGenre.add(GenresItemMovie("Drama", 18))
        movieGenre.add(GenresItemMovie("Sci-Fi & Fantasy", 10765))

        return movieGenre
    }

    fun generateDummyTVGenreRemote(): List<GenresItemTVShow> {

        val tvGenre = ArrayList<GenresItemTVShow>()

        tvGenre.add(GenresItemTVShow("Fantasy", 14))
        tvGenre.add(GenresItemTVShow("Action", 28))
        tvGenre.add(GenresItemTVShow("Adventure", 12))
        tvGenre.add(GenresItemTVShow("Science Fiction", 878))
        tvGenre.add(GenresItemTVShow("Thriller", 53))

        return tvGenre
    }
}