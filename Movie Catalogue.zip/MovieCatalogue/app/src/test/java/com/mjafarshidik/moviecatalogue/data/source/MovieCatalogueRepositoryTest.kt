package com.mjafarshidik.moviecatalogue.data.source

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.mjafarshidik.moviecatalogue.data.source.remote.RemoteDataSource
import com.mjafarshidik.moviecatalogue.utils.DataDummy
import com.mjafarshidik.moviecatalogue.utils.LiveDataTestUtil
import com.nhaarman.mockitokotlin2.any
import com.nhaarman.mockitokotlin2.eq
import com.nhaarman.mockitokotlin2.verify
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.mockito.Mockito

class MovieCatalogueRepositoryTest {
    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    private val remote = Mockito.mock(RemoteDataSource::class.java)
    private val dataRepository = FakeDataRepository(remote)

    private val movieResponses = DataDummy.generateDummyMoviesRemote()
    private val movieResponsesDetail = DataDummy.generateDummyMoviesRemote()[0]
    private val movieResponsesGenre = DataDummy.generateDummyMovieGenreRemote()
    private val movieId = movieResponses[0].id
    private val tvShowsResponses = DataDummy.generateDummyTVShowsRemote()
    private val tvShowsResponsesDetail = DataDummy.generateDummyTVShowsRemote()[0]
    private val tvShowsResponsesGenre = DataDummy.generateDummyTVGenreRemote()
    private val tvShowsId = tvShowsResponses[0].id

    @Test
    fun getMovies() {
        runBlocking {
            Mockito.doAnswer { invocation ->
                (invocation.arguments[0] as RemoteDataSource.LoadMoviesCallback)
                    .onAllMovieReceived(movieResponses)
                null
            }.`when`(remote).getMovies(any())
        }

        val movieEntities = LiveDataTestUtil.getValue(dataRepository.getMovies())
        runBlocking { verify(remote).getMovies(any()) }
        assertNotNull(movieEntities)
        assertEquals(movieResponses.size.toLong(), movieEntities.size.toLong())
    }

    @Test
    fun getMoviesDetail() {
        runBlocking {
            Mockito.doAnswer { invocation ->
                (invocation.arguments[1] as RemoteDataSource.LoadDetailMovieCallback)
                    .onMovieReceived(movieResponsesDetail)
                null
            }.`when`(remote).getDetailMovies(eq(movieId), any())
        }

        val movieDetail = LiveDataTestUtil.getValue(dataRepository.getDetailMovies(movieId))
        runBlocking { verify(remote).getDetailMovies(eq(movieId), any()) }
        assertNotNull(movieDetail)
        assertEquals(movieResponsesDetail.id, movieDetail.id)
    }

    @Test
    fun getMoviesGenre() {
        runBlocking {
            Mockito.doAnswer { invocation ->
                (invocation.arguments[1] as RemoteDataSource.LoadMovieGenreCallback)
                    .onMovieGenreReceived(movieResponsesGenre)
                null
            }.`when`(remote).getMovieGenre(eq(movieId), any())
        }

        val movieGenre = LiveDataTestUtil.getValue(dataRepository.getMoviesGenre(movieId))
        runBlocking { verify(remote).getMovieGenre(eq(movieId), any()) }
        assertNotNull(movieGenre)
        assertEquals(movieResponsesGenre.size.toLong(), movieGenre.size.toLong())
    }

    @Test
    fun getTVShows() {
        runBlocking {
            Mockito.doAnswer { invocation ->
                (invocation.arguments[0] as RemoteDataSource.LoadTvShowsCallback)
                    .onAllTVReceived(tvShowsResponses)
                null
            }.`when`(remote).getTvShows(any())
        }

        val tvEntities = LiveDataTestUtil.getValue(dataRepository.getTvShows())
        runBlocking { verify(remote).getTvShows(any()) }
        assertNotNull(tvEntities)
        assertEquals(tvShowsResponses.size.toLong(), tvEntities.size.toLong())
    }

    @Test
    fun getTVShowsDetail() {
        runBlocking {
            Mockito.doAnswer { invocation ->
                (invocation.arguments[1] as RemoteDataSource.LoadDetailTvShowCallback)
                    .onTVReceived(tvShowsResponsesDetail)
                null
            }.`when`(remote).getDetailTvShow(eq(tvShowsId), any())
        }

        val tvDetail = LiveDataTestUtil.getValue(dataRepository.getDetailTvShow(tvShowsId))
        runBlocking { verify(remote).getDetailTvShow(eq(tvShowsId), any()) }
        assertNotNull(tvDetail)
        assertEquals(tvShowsResponsesDetail.id, tvDetail.id)
    }

    @Test
    fun getTVShowsGenre() {
        runBlocking {
            Mockito.doAnswer { invocation ->
                (invocation.arguments[1] as RemoteDataSource.LoadTVGenreCallback)
                    .onTVGenreReceived(tvShowsResponsesGenre)
                null
            }.`when`(remote).getTVGenre(eq(tvShowsId), any())
        }

        val tvGenre = LiveDataTestUtil.getValue(dataRepository.getTVShowsGenre(tvShowsId))
        runBlocking { verify(remote).getTVGenre(eq(tvShowsId), any()) }
        assertNotNull(tvGenre)
        assertEquals(tvShowsResponsesGenre.size.toLong(), tvGenre.size.toLong())
    }
}