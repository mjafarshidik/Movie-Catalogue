package com.mjafarshidik.moviecatalogue.ui.detail

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.mjafarshidik.moviecatalogue.data.source.MovieCatalogueRepository
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity
import com.mjafarshidik.moviecatalogue.data.source.local.DataGenre
import com.mjafarshidik.moviecatalogue.utils.DataDummy
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {

    private lateinit var viewModel: DetailViewModel

    private val dummyMovie = DataDummy.getAllMovies()[0]
    private val movieId = dummyMovie.id
    private val dummyTVShow = DataDummy.getAllTvShows()[0]
    private val tvId = dummyTVShow.id

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var dataRepository: MovieCatalogueRepository

    @Mock
    private lateinit var observer: Observer<DataEntity>

    @Mock
    private lateinit var observerGenre: Observer<List<DataGenre>>

    @Before
    fun setUp() {
        viewModel = DetailViewModel(dataRepository)
    }

    @Test
    fun getMovieDetail() {
        val movies = MutableLiveData<DataEntity>()
        movies.value = dummyMovie

        Mockito.`when`(dataRepository.getDetailMovies(movieId)).thenReturn(movies)
        val moviesEntity = viewModel.getDetailMovies(movieId).value as DataEntity

        Mockito.verify(dataRepository).getDetailMovies(movieId)
        assertNotNull(moviesEntity)
        assertEquals(dummyMovie.id, moviesEntity.id)
        assertEquals(dummyMovie.poster, moviesEntity.poster)
        assertEquals(dummyMovie.title, moviesEntity.title)
        assertEquals(dummyMovie.date, moviesEntity.date)
        assertEquals(dummyMovie.score, moviesEntity.score)
        assertEquals(dummyMovie.overview, moviesEntity.overview)

        viewModel.getDetailMovies(movieId).observeForever(observer)
        Mockito.verify(observer).onChanged(dummyMovie)


    }

    @Test
    fun getTVShowsDetail() {
        val tvShows = MutableLiveData<DataEntity>()
        tvShows.value = dummyTVShow

        Mockito.`when`(dataRepository.getDetailTvShow(tvId)).thenReturn(tvShows)
        val tvShowsEntity = viewModel.getDetailTvShow(tvId).value as DataEntity

        Mockito.verify(dataRepository).getDetailTvShow(tvId)
        assertNotNull(tvShowsEntity)
        assertEquals(dummyTVShow.id, tvShowsEntity.id)
        assertEquals(dummyTVShow.poster, tvShowsEntity.poster)
        assertEquals(dummyTVShow.title, tvShowsEntity.title)
        assertEquals(dummyTVShow.date, tvShowsEntity.date)
        assertEquals(dummyTVShow.score, tvShowsEntity.score)
        assertEquals(dummyTVShow.overview, tvShowsEntity.overview)

        viewModel.getDetailTvShow(tvId).observeForever(observer)
        Mockito.verify(observer).onChanged(dummyTVShow)

    }

    @Test
    fun getMovieGenre() {
        val dummyGenreMovies = DataDummy.generateDummyMovieGenre()
        val genreMovies = MutableLiveData<List<DataGenre>>()
        genreMovies.value = dummyGenreMovies

        Mockito.`when`(dataRepository.getMoviesGenre(movieId)).thenReturn(genreMovies)

        val genreEntities = viewModel.getMovieGenre(movieId).value

        Mockito.verify(dataRepository).getMoviesGenre(movieId)
        assertNotNull(genreEntities)

        viewModel.getMovieGenre(movieId).observeForever(observerGenre)
        Mockito.verify(observerGenre).onChanged(dummyGenreMovies)

    }

    @Test
    fun getTVShowsGenre() {
        val dummyGenreTVShows = DataDummy.generateDummyTVGenre()
        val genreTVShows = MutableLiveData<List<DataGenre>>()
        genreTVShows.value = dummyGenreTVShows

        Mockito.`when`(dataRepository.getTVShowsGenre(tvId)).thenReturn(genreTVShows)

        val genreEntities = viewModel.getTVShowsGenre(tvId).value

        Mockito.verify(dataRepository).getTVShowsGenre(tvId)
        assertNotNull(genreEntities)

        viewModel.getTVShowsGenre(tvId).observeForever(observerGenre)
        Mockito.verify(observerGenre).onChanged(dummyGenreTVShows)

    }
}