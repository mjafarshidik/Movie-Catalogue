package com.mjafarshidik.moviecatalogue.ui.tvshows

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.mjafarshidik.moviecatalogue.data.source.MovieCatalogueRepository
import com.mjafarshidik.moviecatalogue.data.source.local.DataEntity
import com.mjafarshidik.moviecatalogue.utils.DataDummy
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class TVShowsViewModelTest {

    private lateinit var viewModel: TVShowsViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var dataRepository: MovieCatalogueRepository

    @Mock
    private lateinit var observer: Observer<List<DataEntity>>


    @Before
    fun setUp() {
        viewModel = TVShowsViewModel(dataRepository)
    }

    @Test
    fun getTv() {
        val dummyTVShow = DataDummy.getAllTvShows()
        val tvShows = MutableLiveData<List<DataEntity>>()
        tvShows.value = dummyTVShow

        Mockito.`when`(dataRepository.getTvShows()).thenReturn(tvShows)

        val tvShowEntities = viewModel.getTv().value
        Mockito.verify(dataRepository).getTvShows()
        assertNotNull(tvShowEntities)
        assertEquals(11, tvShowEntities?.size)

        viewModel.getTv().observeForever(observer)
        Mockito.verify(observer).onChanged(dummyTVShow)
    }
}